#ifndef HAS_DESCRIBE_VERSION_H
#define HAS_DESCRIBE_VERSION_H

#define VERSION "0.2.0"

#endif

