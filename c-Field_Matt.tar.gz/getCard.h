#ifndef HAS_GET_CARD_H
#define HAS_GET_CARD_H
#include <getCUDA.h>

void getCard(int cardNum);

#endif

