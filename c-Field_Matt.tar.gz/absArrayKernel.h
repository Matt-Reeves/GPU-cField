#ifndef HAS_ABS_ARRAY_KERNEL_H
#define HAS_ABS_ARRAY_KERNEL_H

__global__ void absArrayKernel( int n, double2* a, double* b );

#endif

