#ifndef HAS_COPY_KERNEL_H
#define HAS_COPY_KERNEL_H

__global__ void copyKernel( int n, double2* a, double2* b );

#endif

